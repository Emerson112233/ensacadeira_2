#pragma once
#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <functional>
#include <cstddef>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <type_traits>
#include <vector>

#define F(x) x
#define HEX 16
#define DEC 10
using byte = uint8_t;

class String {
 public:
  std::string value;
  String() = default;
  String(const char* s): value(s ? s : "") {}
  String(const std::string& s): value(s) {}
  String(char c): value(1,c) {}
  template<class T, typename std::enable_if<std::is_integral<T>::value && !std::is_same<T,char>::value,int>::type=0>
  String(T number, unsigned char base=10) {
    std::ostringstream ss;
    if (base==16) ss << std::hex;
    if (std::is_signed<T>::value) ss << static_cast<long long>(number);
    else ss << static_cast<unsigned long long>(number);
    value=ss.str();
  }
  String(double number,unsigned char decimals=2) {
    std::ostringstream ss; ss << std::fixed << std::setprecision(decimals) << number; value=ss.str();
  }
  const char* c_str() const { return value.c_str(); }
  unsigned int length() const { return static_cast<unsigned int>(value.size()); }
  bool isEmpty() const { return value.empty(); }
  bool reserve(unsigned int size) { value.reserve(size); return true; }
  char operator[](size_t n) const { return n<value.size() ? value[n] : '\0'; }
  char& operator[](size_t n) { return value[n]; }
  String& operator+=(const String& b) {value+=b.value; return *this;}
  String& operator+=(char b) {value+=b; return *this;}
  String& operator+=(const char* b) {value+=b; return *this;}
  friend String operator+(const String& a,const String& b) {return String(a.value+b.value);}
  friend bool operator==(const String& a,const String& b) {return a.value==b.value;}
  friend bool operator!=(const String& a,const String& b) {return !(a==b);}
  friend bool operator<(const String& a,const String& b) {return a.value<b.value;}
  friend std::ostream& operator<<(std::ostream& o,const String& s) {return o<<s.value;}
  int indexOf(char c,unsigned int from=0) const {auto n=value.find(c,from); return n==std::string::npos ? -1 : static_cast<int>(n);}
  int indexOf(const String& s,unsigned int from=0) const {auto n=value.find(s.value,from); return n==std::string::npos ? -1 : static_cast<int>(n);}
  int lastIndexOf(char c) const {auto n=value.rfind(c); return n==std::string::npos ? -1 : static_cast<int>(n);}
  int lastIndexOf(const String& s) const {auto n=value.rfind(s.value); return n==std::string::npos ? -1 : static_cast<int>(n);}
  String substring(unsigned int begin,unsigned int end) const {
    if (begin>end) std::swap(begin,end);
    begin=std::min(begin,length()); end=std::min(end,length());
    return value.substr(begin,end-begin);
  }
  String substring(unsigned int begin) const {return substring(begin,length());}
  bool startsWith(const String& s,unsigned int from=0) const {return from<=value.size() && value.compare(from,s.value.size(),s.value)==0;}
  bool endsWith(const String& s) const {return s.length()<=length() && value.compare(length()-s.length(),s.length(),s.value)==0;}
  long toInt() const {return std::strtol(c_str(),nullptr,10);}
  float toFloat() const {return std::strtof(c_str(),nullptr);}
  void replace(const String& from,const String& to) {
    if (!from.length()) return;
    size_t p=0; while ((p=value.find(from.value,p))!=std::string::npos) {value.replace(p,from.length(),to.value); p+=to.length();}
  }
  void replace(char from,char to) {std::replace(value.begin(),value.end(),from,to);}
  void trim() {size_t first=value.find_first_not_of(" \t\r\n"); if(first==std::string::npos){value.clear();return;} value=value.substr(first,value.find_last_not_of(" \t\r\n")-first+1);}
  void remove(unsigned int index,unsigned int count=~0u) {if(index<length()) value.erase(index,count);}
  void toCharArray(char* destination,unsigned int size)const{if(!size)return;size_t n=std::min(static_cast<size_t>(size-1),value.size());std::memcpy(destination,value.data(),n);destination[n]=0;}
  void toLowerCase() {for(char& c:value)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));}
};

enum SeekMode {SeekSet,SeekCur,SeekEnd};
struct FSInfo {size_t totalBytes=2*1024*1024;size_t usedBytes=0;};
class MockFS;
class File {
 public:
  struct Handle {MockFS* fs; std::string path;size_t position;bool writable;bool closed=false;bool writeError=false;};
  std::shared_ptr<Handle> h;
  File()=default;
  explicit File(std::shared_ptr<Handle> p):h(std::move(p)){}
  operator bool() const {return h && !h->closed;}
  size_t size() const;
  size_t position() const {return *this ? h->position : 0;}
  int available() const {return *this && h->position<size() ? static_cast<int>(size()-h->position) : 0;}
  int read();
  size_t read(uint8_t* buffer,size_t size);
  size_t readBytes(char* buffer,size_t size) {return read(reinterpret_cast<uint8_t*>(buffer),size);}
  size_t write(const uint8_t* buffer,size_t size);
  size_t write(uint8_t c) {return write(&c,1);}
  size_t print(const String& s) {return write(reinterpret_cast<const uint8_t*>(s.c_str()),s.length());}
  size_t print(const char* s) {return print(String(s));}
  size_t print(char c) {return write(static_cast<uint8_t>(c));}
  template<class T> size_t print(T value) {return print(String(value));}
  size_t println(const String& s) {size_t a=print(s);return a+print('\n');}
  String readStringUntil(char delimiter) {String s;while(available()){int c=read();if(c==delimiter)break;s+=static_cast<char>(c);}return s;}
  bool seek(uint32_t pos,SeekMode mode=SeekSet) {if(!*this)return false;size_t base=mode==SeekSet?0:(mode==SeekCur?h->position:size());if(base+pos>size())return false;h->position=base+pos;return true;}
  bool truncate(uint32_t n);
  void flush();
  void close();
  int getWriteError() const {return *this && h->writeError ? 1 : 0;}
  void clearWriteError() {if(*this)h->writeError=false;}
};

class MockFS {
 public:
  std::map<std::string,std::string> files;
  size_t totalBytes=2*1024*1024;
  std::string failOpenPath;
  std::string failOpenMode;
  std::string failRenameFrom;
  std::string failRemovePath;
  std::string limitWritePath;
  long writeBudget=-1;
  long nextWriteLimit=-1;
  std::function<void(const std::string&)> beforeWrite;
  bool failTruncate=false;
  bool failFlush=false;
  size_t writeCalls=0;
  size_t renameCalls=0;
  size_t flushCalls=0;
  void faultsOff(){failOpenPath.clear();failOpenMode.clear();failRenameFrom.clear();failRemovePath.clear();limitWritePath.clear();writeBudget=-1;nextWriteLimit=-1;beforeWrite=nullptr;failTruncate=false;failFlush=false;}
  void clear(){files.clear();totalBytes=2*1024*1024;faultsOff();writeCalls=renameCalls=flushCalls=0;}
  bool exists(const char* p) const {return files.count(p)>0;}
  bool exists(const String& p) const {return exists(p.c_str());}
  File open(const char* p,const char* mode){
    if(failOpenPath==p&&(failOpenMode.empty()||failOpenMode==mode))return {};
    bool w=std::strchr(mode,'w'),a=std::strchr(mode,'a'),plus=std::strchr(mode,'+');
    if(!w&&!a&&!exists(p))return {};
    if(w)files[p].clear();
    if(a&&!exists(p))files[p]="";
    auto h=std::make_shared<File::Handle>();h->fs=this;h->path=p;h->position=a?files[p].size():0;h->writable=w||a||plus;return File(h);
  }
  File open(const String& p,const char* m){return open(p.c_str(),m);}
  bool remove(const char* p){if(failRemovePath==p)return false;return files.erase(p)>0;}
  bool rename(const char* from,const char* to){renameCalls++;if(failRenameFrom==from||!exists(from))return false;auto data=files[from];files.erase(from);files[to]=data;return true;}
  bool info(FSInfo& info)const{info.totalBytes=totalBytes;info.usedBytes=0;for(auto& x:files)info.usedBytes+=x.second.size();return true;}
};

inline size_t File::size()const {if(!*this)return 0;auto it=h->fs->files.find(h->path);return it==h->fs->files.end()?0:it->second.size();}
inline int File::read(){if(!*this||h->position>=size())return -1;return static_cast<unsigned char>(h->fs->files[h->path][h->position++]);}
inline size_t File::read(uint8_t* b,size_t n){size_t count=0;while(count<n&&available()){b[count++]=static_cast<uint8_t>(read());}return count;}
inline size_t File::write(const uint8_t* b,size_t n){
  if(!*this||!h->writable)return 0;
  h->fs->writeCalls++;
  if(h->fs->beforeWrite)h->fs->beforeWrite(h->path);
  size_t accepted=n;
  if(h->fs->nextWriteLimit>=0&&(h->fs->limitWritePath.empty()||h->fs->limitWritePath==h->path)){accepted=std::min(accepted,static_cast<size_t>(h->fs->nextWriteLimit));h->fs->nextWriteLimit=-1;}
  if(h->fs->writeBudget>=0&&(h->fs->limitWritePath.empty()||h->fs->limitWritePath==h->path)){
    accepted=std::min(accepted,static_cast<size_t>(h->fs->writeBudget));h->fs->writeBudget-=accepted;
  }
  if(accepted<n)h->writeError=true;
  auto& content=h->fs->files[h->path];
  if(h->position+accepted>content.size())content.resize(h->position+accepted,'\0');
  content.replace(h->position,accepted,reinterpret_cast<const char*>(b),accepted);h->position+=accepted;return accepted;
}
inline bool File::truncate(uint32_t n){if(!*this||!h->writable||h->fs->failTruncate)return false;h->fs->files[h->path].resize(n);h->position=std::min(h->position,static_cast<size_t>(n));return true;}
inline void File::flush(){if(*this){h->fs->flushCalls++;if(h->fs->failFlush)h->writeError=true;}}
inline void File::close(){if(h){flush();h->closed=true;}}

inline MockFS LittleFS;
inline uint32_t mockMillis=0;
inline unsigned long millis(){return mockMillis;}
inline void yield(){}
inline void delay(unsigned long dt){mockMillis+=dt;}
struct MockESP {uint32_t getChipId()const{return 0x123456;} uint32_t getFreeHeap()const{return 15000;}};
inline MockESP ESP;

using std::min;
using std::max;
