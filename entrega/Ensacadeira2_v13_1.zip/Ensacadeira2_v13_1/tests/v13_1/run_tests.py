#!/usr/bin/env python3
"""Exercise the actual v13 sketch on the host, without hardware or network.

Requires Python 3 and g++ with ASan/UBSan support. Generated sources and binaries
are temporary. Firmware engine, queue and adapter code are read from the sketch;
the Arduino, LittleFS, clock and Firebase boundaries use deterministic mocks.
"""
import argparse
from pathlib import Path
import subprocess
import sys
import tempfile

sys.dont_write_bytecode=True
from run_queue_tests import HERE, default_sketch

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--sketch',type=Path,default=default_sketch())
    args=parser.parse_args()
    sketch=args.sketch.resolve()
    source=sketch.read_text()
    engine=source.split('// BEGIN V13 ENGINE',1)[1].split('// END V13 ENGINE',1)[0]
    with tempfile.TemporaryDirectory(prefix='ensacadeira-v13-engine-') as directory:
        build=Path(directory)
        (build/'v13_cycle.inc').write_text(engine)
        executable=build/'cycle_tests'
        print('Testing cycle/weight engine extracted from the selected sketch...',flush=True)
        subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-g',
                        '-fsanitize=address,undefined','-fno-omit-frame-pointer',
                        '-I',str(build),str(HERE/'test_cycle.cpp'),'-o',str(executable)],check=True)
        subprocess.run([str(executable)],check=True)
    for runner in ['run_queue_tests.py','run_adapter_tests.py']:
        print('Running '+runner+' against the selected sketch...',flush=True)
        subprocess.run([sys.executable,'-B',str(HERE/runner),'--sketch',str(sketch)],check=True)
    print('Running recorded-PKT replay against the selected sketch...',flush=True)
    subprocess.run([sys.executable,'-B',str(HERE/'run_adapter_tests.py'),'--sketch',str(sketch),'--replay'],check=True)
    print('All 4 suites passed. No network or hardware requests.')

if __name__=='__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.returncode)
