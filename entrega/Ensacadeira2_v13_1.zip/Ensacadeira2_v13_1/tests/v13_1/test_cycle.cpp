#include "v13_cycle.inc"
#include <cassert>
#include <cstring>
#include <iostream>
#include <limits>
#include <vector>

using namespace E2V13;

struct Rig {
  Engine engine;
  uint32_t now = 0;
  explicit Rig(int32_t limit = 100) {
    assert(engine.begin(limit));
    tick(0, false);
    tick(0, false);
    assert(engine.state().primed);
  }
  Step tick(int32_t raw, bool sp3 = true, bool unstable = false,
            uint32_t delta = 250) {
    now += delta;
    return engine.feed(raw, sp3, unstable, now);
  }
  void sequence(const std::vector<int32_t>& values, bool unstable = false) {
    for (int32_t raw : values) tick(raw, true, unstable);
  }
};

static void example_stable() {
  Rig r;
  r.sequence({248,256,245,246,247,248,249,249,251,250,245,200,100,3});
  assert(!r.engine.pending());
  assert(r.engine.state().active);
  assert(r.engine.state().lowCount == 1);
  assert(r.tick(3) == Step::Ready);
  assert(r.engine.result().raw == 250);
  assert(r.engine.result().stable);
  assert(r.engine.result().maximumRaw == 256);
  assert(r.engine.result().readings == 15);
  assert(!r.engine.result().ambiguous);
}

static void example_median() {
  Rig r;
  r.sequence({248,256,245,246,247,248,249,249,251,250,245,200,100,3,3}, true);
  assert(r.engine.pending());
  assert(r.engine.result().raw == 250);
  assert(r.engine.result().quality == Quality::Median);
  assert(!r.engine.result().stable);
}

static void legitimate_plateaus() {
  Rig constant;
  constant.sequence({245,245,245,245,0,0});
  assert(constant.engine.result().raw == 245);
  assert(constant.engine.result().stable);

  Rig lower;
  lower.sequence({250,250,250,245,245,245,0,0});
  assert(lower.engine.result().raw == 245);
  assert(lower.engine.result().stable);
  assert(lower.engine.result().ambiguous);

  Rig lowerMedian;
  lowerMedian.sequence({250,250,250,245,246,245,0,0}, true);
  assert(lowerMedian.engine.result().raw == 245);
  assert(lowerMedian.engine.result().quality == Quality::Median);

  Rig subsequentUnload;
  subsequentUnload.sequence({250,250,250,245,245,245,200,100,3,3});
  assert(subsequentUnload.engine.result().raw == 245);

  Rig legitimate245MedianBeforeUnload;
  legitimate245MedianBeforeUnload.sequence({250,250});
  legitimate245MedianBeforeUnload.sequence({245,245,245,200,100,3,3}, true);
  assert(legitimate245MedianBeforeUnload.engine.result().raw == 245);
  assert(legitimate245MedianBeforeUnload.engine.result().quality == Quality::Median);
  assert(legitimate245MedianBeforeUnload.engine.result().ambiguous);

  Rig stableWhileFilling;
  stableWhileFilling.sequence({198,198});
  stableWhileFilling.sequence({248,249,250,250,0,0}, true);
  assert(stableWhileFilling.engine.result().raw == 250);
  assert(stableWhileFilling.engine.result().quality == Quality::Median);

  Rig oldStable245;
  oldStable245.sequence({245,245});
  oldStable245.sequence({249,251,250,0,0}, true);
  assert(oldStable245.engine.result().raw == 250);
  assert(oldStable245.engine.result().quality == Quality::Median);

  Rig stableStillConsistent;
  stableStillConsistent.sequence({250,250});
  stableStillConsistent.sequence({249,251,250,0,0}, true);
  assert(stableStillConsistent.engine.result().raw == 250);
  assert(stableStillConsistent.engine.result().quality == Quality::Stable);

  Rig staleIrregular;
  staleIrregular.sequence({200,200});
  for (int i = 0; i < 5; ++i) staleIrregular.sequence({248,253,247,252}, true);
  staleIrregular.sequence({0,0}, true);
  assert(staleIrregular.engine.result().raw == 252);
  assert(staleIrregular.engine.result().quality == Quality::Unconfirmed);
  assert(staleIrregular.engine.result().ambiguous);

  Rig recoveredDischarge;
  recoveredDischarge.sequence({250,250,250,245,200,260,260,260,0,0});
  assert(recoveredDischarge.engine.result().raw == 260);
  assert(recoveredDischarge.engine.result().stable);
  assert(recoveredDischarge.engine.result().ambiguous);

  Rig reboundSpike;
  reboundSpike.sequence({250,250,250,245,200,260,260,0,0});
  assert(reboundSpike.engine.result().raw == 250); // Recovery needs three.
}

static void no_sp3_or_time_completion() {
  Rig r;
  r.sequence({248,249,250});
  for (int i = 0; i < 150; ++i) {
    r.tick(250, (i % 2) != 0, false, 1000000);
    assert(r.engine.state().active);
    assert(!r.engine.pending());
  }
  assert(r.engine.state().cycleNumber == 1);
  r.tick(0, false);
  assert(!r.engine.pending());
  r.tick(0, false);
  assert(r.engine.pending());
  assert(r.engine.result().cycleNumber == 1);
}

static void strict_two_low_and_gap() {
  Rig r;
  r.sequence({250,250,250,100,100,100});
  assert(!r.engine.pending());
  assert(r.engine.state().lowCount == 0);
  r.tick(99);
  assert(r.engine.state().lowCount == 1);
  r.tick(100);
  assert(r.engine.state().lowCount == 0);
  r.tick(99);
  r.engine.invalidate();
  assert(r.engine.state().lowCount == 0);
  assert(r.engine.state().active);
  assert(r.engine.state().gap);
  assert(r.engine.state().windowCount == 0);
  r.tick(99);
  assert(!r.engine.pending());
  r.tick(99);
  assert(r.engine.pending());
  assert(r.engine.result().raw == 250);
  assert(r.engine.result().gap);
  assert(r.engine.result().durationApproximate);
}

static void invalid_not_low() {
  Rig r;
  r.sequence({250,250,250,3});
  assert(r.tick(-1) == Step::Invalid);
  assert(r.engine.state().lowCount == 0);
  r.tick(3);
  assert(!r.engine.pending());
  r.tick(3);
  assert(r.engine.pending());
}

static void stable_group_cannot_cross_invalid() {
  Rig r;
  r.tick(250);
  assert(r.engine.state().candidate.quality == Quality::Unconfirmed);
  r.engine.invalidate();
  r.tick(250);
  assert(r.engine.state().candidate.quality == Quality::Unconfirmed);
  r.tick(250);
  assert(r.engine.state().candidate.quality == Quality::Stable);
}

static void pending_commit_and_rearm() {
  Rig r;
  r.sequence({250,250,250,0,0});
  const State saved = r.engine.snapshot();
  assert(r.tick(400, false) == Step::Pending);
  assert(std::memcmp(&saved, &r.engine.state(), sizeof(State)) == 0);
  assert(!r.engine.reset());
  assert(!r.engine.configure(defaultConfig()));
  assert(r.engine.acknowledge());
  assert(!r.engine.acknowledge());
  assert(r.tick(250, true) == Step::Ignored); // SP3 was still high at completion.
  r.tick(0, false);
  assert(r.tick(245, true) == Step::Started);
  r.sequence({245,245,0,0});
  assert(r.engine.result().cycleNumber == 2);
  assert(r.engine.result().raw == 245);

  assert(r.engine.acknowledge());
  for (int i = 0; i < 20; ++i) r.tick(0, (i % 2) != 0);
  assert(!r.engine.pending());
  assert(r.engine.state().active);
  assert(!r.engine.state().loadSeen);
  r.sequence({245,245,245,0,0});
  assert(r.engine.pending());
  assert(r.engine.result().raw == 245);
}

static void cold_boot_priming() {
  Engine engine;
  for (uint32_t t = 1; t < 30; ++t) {
    engine.feed(250, (t % 2) != 0, false, t);
    assert(!engine.state().active);
  }
  engine.feed(0, false, false, 31);
  engine.invalidate();
  engine.feed(0, false, false, 32);
  assert(!engine.state().primed);
  engine.feed(0, false, false, 33);
  assert(engine.state().primed);
  assert(engine.feed(250, true, false, 34) == Step::Started);

  Rig emptyPulse;
  assert(emptyPulse.tick(0, true) == Step::Started);
  emptyPulse.tick(0, false);
  assert(emptyPulse.engine.state().active);
  emptyPulse.tick(0, false);
  assert(!emptyPulse.engine.state().active);
  assert(!emptyPulse.engine.pending());
  assert(emptyPulse.tick(250, true) == Step::Started);
  emptyPulse.sequence({250,250,0,0});
  assert(emptyPulse.engine.pending());
  assert(emptyPulse.engine.result().raw == 250);

  Rig highBeforeFill;
  highBeforeFill.sequence({0,0,0});
  assert(highBeforeFill.engine.state().active);
  assert(!highBeforeFill.engine.pending());
  highBeforeFill.sequence({250,250,250,0,0});
  assert(highBeforeFill.engine.pending());
  assert(highBeforeFill.engine.result().raw == 250);
}

static void restore_active_and_pending() {
  Rig r;
  r.sequence({250,250,250,3});
  const State saved = r.engine.snapshot();
  Engine recovered;
  assert(recovered.restore(saved));
  recovered.invalidate();
  recovered.rebaseClock(10);
  assert(recovered.state().active);
  recovered.feed(3, true, false, 20);
  assert(!recovered.pending());
  recovered.feed(3, true, false, 30);
  assert(recovered.pending());
  assert(recovered.result().raw == 250);
  assert(recovered.result().durationMs < 10000);
  assert(recovered.result().durationApproximate);
  const State ready = recovered.snapshot();
  Engine readyRestored;
  assert(readyRestored.restore(ready));
  assert(readyRestored.pending());
  assert(readyRestored.result().raw == 250);
  readyRestored.invalidate();
  assert(std::memcmp(&ready, &readyRestored.state(), sizeof(State)) == 0);
  State broken = ready;
  broken.version++;
  Engine bad;
  assert(!bad.restore(broken));
}

static void history_bounds_and_clock_wrap() {
  Rig r;
  r.now = UINT32_MAX - 1000;
  r.tick(250);
  for (int32_t i = 0; i < 40; ++i) r.tick(250);
  assert(r.engine.state().historyCount == 15);
  assert(r.engine.state().historyHead < 15);
  r.tick(0);
  r.tick(0);
  assert(r.engine.result().durationMs == 42 * 250);
  const State& s = r.engine.state();
  const uint8_t newest = static_cast<uint8_t>((s.historyHead + 14) % 15);
  assert(s.history[newest].raw == 0);
  assert(s.history[newest].ms == r.now);
}

static void uncertain_is_not_maximum() {
  Rig r;
  r.sequence({248,256,0,0}, true);
  assert(r.engine.result().raw == 252); // Median available pair, not max256.
  assert(r.engine.result().quality == Quality::Unconfirmed);
  assert(r.engine.result().ambiguous);

  Rig empty;
  empty.sequence({0,0,0,0});
  assert(!empty.engine.pending());
  assert(empty.engine.state().active);
  assert(empty.engine.state().lowCount == 0);
  empty.sequence({245,245,245,0,0});
  assert(empty.engine.result().raw == 245);
}

static void configurable_50kg_limit_and_large_raw() {
  Rig fifty(200);
  fifty.sequence({498,500,500,200,199,199});
  assert(fifty.engine.pending());
  assert(fifty.engine.result().raw == 500);
  Rig big;
  big.sequence({INT32_MAX,INT32_MAX,INT32_MAX,0,0});
  assert(big.engine.result().raw == INT32_MAX);
  Config bad = defaultConfig();
  bad.lowLimitRaw = 0;
  Engine engine;
  assert(!engine.begin(bad));
}

static void final_pair_is_insufficient_estimate() {
  const std::vector<std::vector<int32_t>> realSequences = {
    {252,256,273,251,251,11,6},
    {253,273,275,251,251,14,5},
    {270,271,272,251,251,14,5}
  };
  for (const auto& values : realSequences) {
    Rig r;
    r.sequence(values, true);
    assert(r.engine.pending());
    assert(r.engine.result().raw == 251);
    assert(r.engine.result().quality == Quality::Unconfirmed);
    assert(!r.engine.result().stable);
    assert(r.engine.result().ambiguous);
  }

  Rig stableMustSurvive;
  stableMustSurvive.sequence({250,250});
  stableMustSurvive.sequence({245,245,11,6}, true);
  assert(stableMustSurvive.engine.result().raw == 250);
  assert(stableMustSurvive.engine.result().quality == Quality::Stable);

  Rig oneSampleNotPair;
  oneSampleNotPair.sequence({248,249,251,250,245,200,100,3,3}, true);
  assert(oneSampleNotPair.engine.result().raw == 250);
  assert(oneSampleNotPair.engine.result().quality == Quality::Median);

  Rig brokenPair;
  brokenPair.sequence({252,256,273,251}, true);
  brokenPair.engine.invalidate();
  brokenPair.sequence({251,11,6}, true);
  assert(brokenPair.engine.result().raw == 256);
  assert(brokenPair.engine.result().gap);

  Rig configuredTolerance;
  Config cfg = defaultConfig();
  cfg.consistentToleranceRaw = 1;
  assert(configuredTolerance.engine.configure(cfg));
  configuredTolerance.sequence({252,256,273,251,253,11,6}, true);
  assert(configuredTolerance.engine.result().raw == 256);
  assert(configuredTolerance.engine.result().quality == Quality::Unconfirmed);
}

static void idle_gap_preserves_arming_and_marks_only_affected_cycle() {
  Rig r;
  r.sequence({250,250,250,0,0});
  assert(r.engine.pending());
  assert(r.engine.acknowledge());
  r.tick(150, false);
  assert(r.engine.state().primed);
  r.engine.invalidate();
  assert(r.engine.state().primed);
  assert(!r.engine.state().sp3Known);
  assert(r.tick(200, false, true, 2116) == Step::Ignored);
  assert(r.tick(249, true, true) == Step::Started);
  r.sequence({250,250,10,5}, true);
  assert(r.engine.pending());
  assert(r.engine.result().gap);
  assert(r.engine.result().ambiguous);
  assert(r.engine.result().durationApproximate);
  assert(r.engine.acknowledge());
  r.tick(0, false);
  assert(r.tick(250, true) == Step::Started);
  r.sequence({250,250,0,0});
  assert(r.engine.pending());
  assert(!r.engine.result().gap);
  assert(!r.engine.result().ambiguous);
  assert(!r.engine.result().durationApproximate);

  Rig returnsHigh;
  returnsHigh.engine.invalidate();
  assert(returnsHigh.tick(250, true) == Step::Ignored);
  assert(!returnsHigh.engine.state().active);
  returnsHigh.tick(250, false);
  assert(returnsHigh.tick(250, true) == Step::Started);

  Engine cold;
  cold.invalidate();
  cold.feed(200, false, true, 1);
  cold.feed(250, true, true, 2);
  assert(!cold.state().active);
  assert(!cold.state().primed);
  cold.feed(0, false, false, 3);
  cold.feed(0, false, false, 4);
  assert(cold.state().primed);
  assert(cold.feed(250, true, false, 5) == Step::Started);
}

int main() {
  example_stable();
  example_median();
  legitimate_plateaus();
  no_sp3_or_time_completion();
  strict_two_low_and_gap();
  invalid_not_low();
  stable_group_cannot_cross_invalid();
  pending_commit_and_rearm();
  cold_boot_priming();
  restore_active_and_pending();
  history_bounds_and_clock_wrap();
  uncertain_is_not_maximum();
  configurable_50kg_limit_and_large_raw();
  final_pair_is_insufficient_estimate();
  idle_gap_preserves_arming_and_marks_only_affected_cycle();
  std::cout << "15 test groups passed; State=" << sizeof(State) << " bytes\n";
}
