#!/usr/bin/env python3
"""Compile and exercise firmware persistence functions using an in-memory FS.

The implementation is extracted from the selected sketch (or, while integrating,
the v13_queue.inc fragment). No network or hardware operations are performed.
"""
from pathlib import Path
import argparse
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
SKETCH_RELATIVE = Path('firmware/Ensacadeira2_RS485_SP3_Estavel_v13_1/Ensacadeira2_RS485_SP3_Estavel_v13_1.ino')

def block(source, start):
    """Brace-matched C++ block, skipping comments and quoted tokens."""
    pos = source.index('{', start)
    depth = 0
    token = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[{}]')
    for match in token.finditer(source, pos):
        if match.group() == '{':
            depth += 1
        elif match.group() == '}':
            depth -= 1
            if depth == 0:
                return source[start:match.end()]
    raise ValueError('Unterminated C++ block')

def function(source, name):
    match = re.search(r'^([^\n;]*\b'+re.escape(name)+r'\([^;\n]*\)\s*\{)', source, re.M)
    if not match:
        raise ValueError('Missing function '+name)
    return block(source, match.start())

def default_sketch():
    for root in HERE.parents:
        candidate=root/SKETCH_RELATIVE
        if candidate.exists():
            return candidate
    raise FileNotFoundError('Run these tests inside the Ensacadeira 2 repository or pass --sketch.')

def generate(sketch, fragment, build_dir=None):
    source = sketch.read_text()
    if fragment:
        implementation = fragment.read_text()
        implementation = implementation.split('// In enviarProximo replace')[0]
        sender = function(fragment.read_text(), 'mesmoPayload13') + '\n' + function(fragment.read_text(), 'enviarProximo')
    else:
        implementation = source.split('// BEGIN V13 QUEUE',1)[1].split('// END V13 QUEUE',1)[0]
        sender = function(source, 'mesmoPayload13') + '\n' + function(source, 'enviarProximo')
    record = block(source, source.index('struct Registro')) + ';'
    legacy = function(source, 'lerRegistroLegado' if 'bool lerRegistroLegado(' in source else 'lerRegistro')
    if not legacy.startswith('bool lerRegistroLegado'):
        legacy = legacy.replace('bool lerRegistro(', 'bool lerRegistroLegado(', 1)
    helper_names = ['extrairStringJson','extrairBoolJson','extrairNumeroJson','lerArquivoTexto','limparTextoFila','tamanhoFila','recalcularPendencias']
    helpers = '\n'.join(function(source, name) for name in helper_names)
    prefix = r'''
#include "arduino_fake.h"
bool littleFsOK=true,memoriaCheia=false;
unsigned long posicaoFila=0;
int pendenciasCache=0;
uint32_t fsLivreCache=2000000;
uint32_t registrosCorrompidos=0;
uint32_t ultimoEnvioOk=0;
uint8_t falhasSeguidas=0;
bool aguardandoResultadoTeste=false;
const size_t TAM_MAX_LINHA=768, RESERVA_FS=128*1024;
const uint32_t LIMITE_REGISTROS_PENDENTES=10000;
const char* ARQUIVO_FILA="/offline.jsonl";
const char* ARQUIVO_REJEITADOS="/fila_rejeitada.txt";
const char* ARQUIVO_POSICAO="/offline_pos.txt";
const char* ARQUIVO_POSICAO_TEMP="/offline_pos.tmp";
const char* FIREBASE_PATH_PESAGENS="/pesagens_2";
const char* FIREBASE_PATH_TESTES="/testes_ensacadeira_2";
const char* FW_VERSAO="E2-RS485-SP3EST-v13";
const int CASAS_DECIMAIS=-1;
bool epochValido(uint32_t t){return t>=1704067200UL&&t<4000000000UL;}
unsigned long tamanhoFila();
void recalcularPendencias();
void atualizarEspacoFs(bool){FSInfo i;LittleFS.info(i);fsLivreCache=i.totalBytes-i.usedBytes;}
int nivelMemoria(){return 0;}
#define TLOG(...) do {} while(0)
void mostrarMensagemTemporaria(const String&,const String&,const String&,uint16_t,unsigned long){}
String formatarData(uint32_t t){return t ? String(t) : String("SEM DATA");}
String formatarHora(uint32_t t){return t ? String(t) : String("SEM HORA");}
enum ResultadoEnvio{ENVIO_NADA,ENVIO_OK,ENVIO_FALHOU,ENVIO_ESPERAR};
struct FirebaseJsonData{
 bool success=false; String type;String value;
 template<class T>T to()const{if constexpr(std::is_same<T,String>::value)return value;else if constexpr(std::is_same<T,bool>::value)return value=="true";else return static_cast<T>(std::stod(value.value));}
};
struct FirebaseJson{
 std::map<std::string,std::string> values,types;
 template<class T> void set(const char* key,const T& v){values[key]=String(v).value;if constexpr(std::is_integral<T>::value)types[key]="int";else if constexpr(std::is_floating_point<T>::value)types[key]="double";else types[key]="string";}
 void set(const char* key,bool v){values[key]=v?"true":"false";types[key]="boolean";}
 void get(FirebaseJsonData& out,const char* key){out.success=values.count(key);if(out.success){out.type=types[key];out.value=values[key];}}
};
struct FirebaseData{int code=0;int httpCode()const{return code;}String errorReason()const{return "mock failure";}};
FirebaseData fbdo;
struct MockRTDB{
 bool success=true,getSuccess=true,loseResponseOnce=false;
 std::vector<std::string> paths;
 std::vector<std::map<std::string,std::string>> payloads;
 std::map<std::string,std::map<std::string,std::string>> server,serverTypes;
 bool setJSON(FirebaseData* data,const char* path,FirebaseJson* j,const char* etag){
  paths.push_back(path);payloads.push_back(j->values);
  if(!success){data->code=503;return false;}
  if(std::string(etag)=="null_etag"&&server.count(path)){data->code=412;return false;}
  server[path]=j->values;serverTypes[path]=j->types;if(loseResponseOnce){loseResponseOnce=false;data->code=503;return false;}data->code=200;return true;
 }
 bool getJSON(FirebaseData* data,const char* path,FirebaseJson* j){if(!getSuccess||!server.count(path)){data->code=503;return false;}j->values=server[path];j->types=serverTypes[path];data->code=200;return true;}
};
struct MockFirebase{MockRTDB RTDB;};
MockFirebase Firebase;
'''
    generated = (build_dir or HERE) / 'queue_source.cpp'
    generated.write_text(prefix + '\n' + record + '\nbool lerRegistroLegado(const String&,Registro&);\n' + helpers + '\n' + legacy + '\n' + implementation + '\n'+function(source,'nomeCriterio')+'\n' + sender + '\n#include "queue_cases.inc"\n')
    return generated

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--sketch',type=Path,default=default_sketch())
    parser.add_argument('--fragment',type=Path)
    parser.add_argument('--integrated',action='store_true')
    args=parser.parse_args()
    fragment=args.fragment
    with tempfile.TemporaryDirectory(prefix='ensacadeira-v13-queue-') as directory:
        build_dir=Path(directory)
        generated=generate(args.sketch,None if args.integrated else fragment,build_dir)
        executable=build_dir/'queue_tests'
        subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Wno-misleading-indentation','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(HERE),str(generated),'-o',str(executable)],check=True)
        subprocess.run([str(executable)],check=True)

if __name__=='__main__':main()
