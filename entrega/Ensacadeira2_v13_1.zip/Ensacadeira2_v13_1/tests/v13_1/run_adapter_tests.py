#!/usr/bin/env python3
"""Run real v13 engine, adapter and queue functions against fault-injected FS."""
from pathlib import Path
import argparse
import sys
sys.dont_write_bytecode=True
import subprocess
import tempfile
import json
import os
from run_queue_tests import generate, function, block, HERE, default_sketch


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--sketch',type=Path,default=default_sketch())
    parser.add_argument('--replay',action='store_true')
    parser.add_argument('--export-dir',type=Path)
    args=parser.parse_args()
    sketch=args.sketch.read_text()
    with tempfile.TemporaryDirectory(prefix='ensacadeira-v13-adapter-base-') as directory:
        base=generate(args.sketch,None,Path(directory)).read_text()
    base=base.rsplit('#include "queue_cases.inc"',1)[0]
    engine=sketch.split('// BEGIN V13 ENGINE',1)[1].split('// END V13 ENGINE',1)[0]
    adapter=sketch.split('// BEGIN V13 ADAPTER',1)[1].split('// END V13 ADAPTER',1)[0]
    wiring='''
String produtos[20]; int indiceAtual=0; uint32_t bootId=1;
unsigned long inicioEsperaTeste=0;
bool registrarPesagem(Registro& r){return filaPersistirRegistro(r);}
uint32_t obterEpochAtual(){return 1793040000UL;}
'''+block(sketch,sketch.index('struct Ciclo'))+';\nCiclo ciclo;\n'+function(sketch,'pesoTexto')+'\n'
    with tempfile.TemporaryDirectory(prefix='ensacadeira-v13-adapter-') as directory:
        build_dir=Path(directory)
        generated=build_dir/'adapter_source.cpp'
        tail='\n#define NO_QUEUE_MAIN\n#include "queue_cases.inc"\n'
        if args.replay:
            tail += '#define NO_ADAPTER_MAIN\n#include "adapter_cases.inc"\nstatic const char* FIXTURE_DIR='+json.dumps(str(HERE/'fixtures'))+';\n#include "replay_cases.inc"\n'
        else:
            tail += '#include "adapter_cases.inc"\n'
        generated.write_text(base+'\n'+engine+'\n'+wiring+adapter+tail)
        exe=build_dir/'adapter_tests'
        subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Wno-misleading-indentation','-Wno-unused-function','-Wno-format-truncation','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(HERE),str(generated),'-o',str(exe)],check=True)
        environment=None
        if args.export_dir:
            args.export_dir.mkdir(parents=True,exist_ok=True)
            environment=os.environ.copy()
            environment['E2_REPLAY_EXPORT']=str(args.export_dir.resolve())
        subprocess.run([str(exe)],check=True,env=environment)

if __name__=='__main__':main()
