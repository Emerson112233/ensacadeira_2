# Ensacadeira 2 — v13.1

Firmware completo:
[`Ensacadeira2_RS485_SP3_Estavel_v13_1.ino`](firmware/Ensacadeira2_RS485_SP3_Estavel_v13_1/Ensacadeira2_RS485_SP3_Estavel_v13_1.ino).

Mudanças, testes e limitações:
[`docs/ANALISE_LOGS_V13_1.md`](docs/ANALISE_LOGS_V13_1.md).
O relatório original da v13 continua em `docs/RELATORIO_V13.md`.

A v12 original e a v13 anterior permanecem intactas.
Abra a pasta do sketch v13.1 na IDE Arduino com ESP8266 core 3.1.2 e as quatro
bibliotecas nas versões do manual. Não há upload ou acesso Firebase automático.

Na nuvem já preparada:

```bash
source /workspace/.cloud-setup/ensacadeira2/activate.sh
cd /workspace/ensacadeira_2
python3 tests/v13_1/run_tests.py
arduino-cli compile --jobs 4 --fqbn "$ENSACADEIRA2_FQBN" \
  --build-path /workspace/.cloud-setup/ensacadeira2/build-v13-1 \
  firmware/Ensacadeira2_RS485_SP3_Estavel_v13_1
```

Para reproduzir as ferramentas: `bash setup/install.sh` neste ambiente Linux
x86_64. Todos os dados mutáveis das ferramentas ficam em `/workspace/.cloud-setup`.
