# Ensacadeira 2 — E2-RS485-SP3EST-v13

Data: 26/10/2026. Base: firmware funcional v12 enviado em `files.zip`.

## Entrega e preservação

O sketch completo e autossuficiente está em
`firmware/Ensacadeira2_RS485_SP3_Estavel_v13/Ensacadeira2_RS485_SP3_Estavel_v13.ino`.
Ele contém o motor de pesagem e a persistência no próprio `.ino`; não depende
dos arquivos de teste para compilar na IDE Arduino.

Os 16 arquivos originais do pacote de manutenção foram preservados, byte a byte,
em `Pacote_Manutencao_Ensacadeira2`. Pinagens, bibliotecas, placeholders de
credenciais, caminhos de produção e configuração de OTA foram preservados. Não
foi feita gravação USB/OTA, alteração do indicador, importação dos JSONs, acesso
ao Firebase real ou envio ao GitHub. Os arquivos novos estão apenas no ambiente.

## Causas encontradas na v12

1. O ciclo terminava após dois pacotes com SP3 desligado, mesmo se o saco
   continuasse sobre a balança. Outra borda de SP3 iniciava outro registro.
2. Havia encerramento por quantidade máxima de pacotes; não confirmava descarga.
3. O peso oficial era a primeira estabilidade encontrada e, sem estabilidade,
   o maior peso do ciclo. Isso favorecia leituras antigas e picos de enchimento.
4. A chave remota podia ser recalculada usando NTP durante envio de eventos sem
   hora. Reenvios em momentos diferentes não tinham identidade imutável.
5. Cursor e contador antigos não tinham validação suficiente contra cortes.
   Além disso, o `LittleFS.begin()` da v12 usava o padrão do core, que permite
   autoformatação em falha de montagem, apesar do comentário dizer o contrário.

## Ciclo e seleção do peso

- SP3 0→1 inicia o ciclo. Oscilações seguintes não o encerram nem criam outro.
- O encerramento exige duas leituras **válidas e consecutivas estritamente
  abaixo** do limite. `00100` é igual ao limite de 25 kg, portanto não conta
  como descarga. Pacotes inválidos e lacunas interrompem a confirmação.
- É necessário observar carga acima do limite. Pulsos de SP3 com balança vazia
  não geram registros; dois baixos com SP3 desligado cancelam o ciclo vazio.
- Não há bloqueio de quatro segundos nem encerramento forçado por tempo.
- O histórico circular guarda as últimas 15 leituras válidas. O estado mantém
  também o último patamar confirmado antes da descarga.
- A última estabilidade aceita exige duas amostras marcadas estáveis, dentro
  de 1 dígito bruto, e consistência com o patamar final. Um estável antigo do
  enchimento não prevalece sobre um grupo final consistente diferente.
- Sem estabilidade adequada, usa a mediana das três últimas amostras de um
  grupo com amplitude de até 3 dígitos brutos. Uma leitura descendente isolada
  não substitui o patamar. Um patamar inferior de três amostras pode ser aceito,
  com sinalização conservadora de ambiguidade; assim, 245 pode ser legítimo.
- Quedas em estágios identificam descarga e preservam o patamar anterior.
  Recuperação de peso exige três amostras consistentes para substituir essa
  hipótese; um pico de retorno isolado não altera o resultado.
- O máximo permanece apenas como diagnóstico. Nunca é o fallback automático.
  Se faltarem amostras adequadas, o resultado é explicitamente não confiável.

O firmware mantém `estavel` e acrescenta `confiavel`, `estimado`, `qualidade`,
`lacuna`, `recuperado`, `amostras`, `limite`, `duracao_ms`, `epoch` e `id`.
`qualidade` vale `S` para estabilidade, `M` para mediana e `I` para amostras
insuficientes/irregulares. Só uma estabilidade sem ambiguidade, lacuna ou
recuperação é marcada confiável. Medianas são marcadas como estimadas. Os campos
originais de data, hora, peso, produto, critério e diagnóstico permanecem.

### Configuração por produto

Em `AJUSTES_DESCARGA13`, os códigos atuais têm os seguintes limites brutos:

| Produto nominal | Códigos atuais | Limite bruto | Confirma descarga quando |
|---|---|---:|---|
| 25 kg | 598, 121, 5375 | 100 | duas leituras < 100 |
| 50 kg | 19, 5270 | 200 | duas leituras < 200 |
| 40 kg | 17800 | 160 | duas leituras < 160 |

Para produtos novos com sufixo `25KG`, `40KG` ou `50KG`, o limite é calculado
como 40% do nominal, usando `ESCALA_LIMITE13=10`. Sem identificação, usa 100.
Os limites podem ser ajustados por código sem alterar pinagens ou o indicador.
Produto e limite são congelados ao abrir o ciclo; trocar produto no visor
durante um ciclo não muda o produto daquele saco.

**A escala pressupõe uma casa decimal**, conforme o pedido. `CASAS_DECIMAIS=-1`
foi mantido como na v12: o campo opcional `peso_kg` continua desabilitado até
confirmação no indicador. O peso bruto de cinco dígitos continua disponível.

## Identidade, fila e reinicialização

1. Ao abrir um ciclo, grava checkpoint em LittleFS, antes de reservar o ID.
2. Reserva contador monotônico de 64 bits em dois slots com CRC e releitura.
   A identidade é `e13_<chip ESP8266>_<contador>`, independente de NTP e millis.
3. Salva o ciclo com ID, produto e horário congelados. Checkpoints alternados
   guardam estado, candidato e confirmação parcial de descarga. O estado do
   motor ocupa 380 bytes; cada checkpoint também leva metadados e CRC.
4. Após descarga confirmada, persiste o evento pendente e só então faz append
   da linha v5 na fila. A linha contém ID, campos e CRC, terminados por newline.
   Escrita parcial não recebe newline; recuperação preserva os bytes rejeitados
   antes de truncar a cauda incompleta.
5. Confirma a fila por flush/close e releitura. Só libera novo ciclo após gravar
   o checkpoint de confirmação. Se houver corte entre append e confirmação,
   localiza o mesmo ID na fila e não o adiciona novamente.
6. No Firebase, usa criação condicional com `null_etag`. Se a resposta anterior
   se perdeu, o retry encontra a mesma chave, compara o payload e confirma sem
   sobrescrever. Um conteúdo divergente pausa o envio; não altera o histórico.
7. O cursor da fila usa slots com CRC. A limpeza usa renomeação para um marcador
   antes de zerar o cursor, evitando que posição antiga pule uma fila nova.

Uma reinicialização recupera o ciclo persistido. Se havia só uma leitura baixa,
exige **duas novas** leituras baixas após o retorno; não une leituras separadas
pela interrupção. Ciclos recuperados/lacunas ficam sinalizados e a duração é
aproximada, sem somar tempo desconhecido de equipamento desligado.

Falha de armazenamento mantém o evento no checkpoint e alerta para pausar a
máquina. Se faltar espaço antes de tentar append, permite drenar eventos
anteriores para liberar a fila. Uma falha de I/O ou confirmação pendente não
libera envio prematuro do evento novo.

Formatos locais antigos 2/3/4/JSON continuam legíveis. Quando uma chave legada
já existe no servidor, a v13 preserva o registro e pausa para conferência, sem
reescrevê-lo. Para legado sem epoch/chave explícita, não é possível reconstruir
com certeza uma chave que a v12 tenha inferido por NTP em uma tentativa passada.

## Validação automatizada

Comando: `python3 tests/v13/run_tests.py`.

As três suítes extraem o código do `.ino` entregue, compilam com g++ e executam
com AddressSanitizer e UndefinedBehaviorSanitizer. A suíte de persistência usa
LittleFS e Firebase simulados, com falhas de escrita, leitura, rename e resposta.
Não há chamadas de rede nem hardware nesses testes.

| Cenário | Resultado verificado |
|---|---|
| Sequência enviada pelo usuário | 250; somente a segunda leitura <100 confirma o registro |
| Mesma sequência sem bit de estabilidade | mediana 250, marcada estimada |
| Patamar legítimo 245, inclusive antes de descarga em estágios | 245 preservado |
| SP3 oscilando enquanto há carga | um evento na descarga, sem ciclos extras |
| Dois sacos com bordas iniciais separadas por 6 segundos | dois IDs e dois eventos |
| Apenas uma leitura abaixo do limite, ou leituras iguais a 100 | nenhum encerramento prematuro |
| SP3 oscilando com balança vazia | nenhum ensaque fantasma |
| Estabilidade antiga no enchimento | substituída/rebaixada quando não sustenta o patamar final |
| Pico máximo e ausência de estabilidade | máximo não escolhido automaticamente |
| Pacote inválido/lacuna entre leituras baixas | confirmação interrompida; evento sinalizado |
| Reinício durante ciclo e entre as duas baixas | ID recuperado; confirmação refeita |
| Corte antes/depois da reserva de ID | evento recuperado, sem reutilizar ID publicado |
| Corte após append, antes de confirmar checkpoint | uma única linha para o mesmo evento |
| Escrita parcial em cada byte da linha/checkpoint/cursor | recuperação ou bloqueio seguro, sem consumir dados incertos |
| Internet indisponível ou resposta de ACK perdida | mesma chave/payload; histórico não sobrescrito |
| Chave remota conflitante ou legado já existente | pausa sem sobrescrever |
| Backlog cheio | drena anterior e persiste o evento retido uma vez |
| Ambos os checkpoints corrompidos | bloqueia operação sem formatar |

Foram aprovados **13 grupos do motor**, **17 cenários da fila** (1.562
assertivas) e **12 cenários do adaptador** (2.703 assertivas). Logs e resultados
da compilação acompanham a entrega em `docs/evidencias/`.

## Ambiente de compilação

- Arduino CLI 1.3.1; arquivo oficial verificado por SHA256.
- ESP8266 Community core 3.1.2.
- Firebase Arduino Client Library for ESP8266 and ESP32 4.4.17.
- GFX Library for Arduino 1.6.9; RTClib 2.1.4; Adafruit BusIO 1.17.4.
- Placa LOLIN(WeMos) D1 R1, CPU 80 MHz, flash 4 MB, LittleFS 2 MB,
  lwIP v2 Lower Memory, VTables Flash e `wipe=none`.

As versões foram instaladas e a instalação repetida com sucesso. A v12 e a v13
foram compiladas realmente. Os únicos avisos observados vieram das expressões
regulares do `elf2bin.py` do core antigo usando Python 3.12; não impediram gerar
o binário. A compilação não comprova uso dinâmico de memória ou funcionamento
dos periféricos no ESP8266 físico.

## Verificações ainda necessárias na máquina

- Confirmar uma casa decimal e limites de descarga em cada produto. Capturar
  logs `PKT` com estabilidade/SP3 para ajustar as tolerâncias sem mascarar sacos.
- Validar RS485/BCC, frequência real dos pacotes, display, botões, RTC, Wi-Fi,
  Telnet, lista de produtos e OTA sob demanda na mesma placa e instalação.
- Medir heap livre no login Firebase e duração das gravações LittleFS em carga.
  O journal aumenta gravações; desgaste e quedas reais de energia precisam de
  ensaio em bancada. Os testes host não modelam eletricamente a memória flash.
- Validar permissões de leitura e criação condicional em uma área de testes
  autorizada do Firebase. A comparação de retry usa o tipo `boolean` real da
  biblioteca 4.4.17, também reproduzido nos mocks.
- Conferir se o dashboard aceita chaves `e13_...`: a data/hora permanece nos
  campos, mas a chave nova não é um epoch numérico. Um dashboard que calcula
  datas ou ordena cronologicamente pela chave pode exigir adaptação separada.
- Preservar LittleFS e manter FS:2MB/Only Sketch. Não apagar a flash: a identidade
  depende dos metadados persistentes. Depois de apagamento/substituição, não
  reutilizar o namespace do mesmo chip sem procedimento de reprovisionamento.
- A v12 não lê fila v5. Não fazer downgrade com eventos v13 pendentes; preservar
  e resolver a fila antes de qualquer retorno.
- Sem alimentação ou comunicação, sacos inteiros não observados não podem ser
  reconstruídos. Uma descarga ruidosa com dois valores baixos falsos pode imitar
  descarga real. Patamares transitórios longos podem ser indistinguíveis de
  patamares finais só com peso/SP3; por isso há sinalização de incerteza.
- Em memória cheia/falha persistente, pausar produção para evitar sacos futuros
  não observados enquanto o evento atual aguarda gravação.

As credenciais do anexo são placeholders e foram mantidas assim. Nenhum binário
foi instalado em operação; a v13 precisa dessa validação de bancada antes disso.
