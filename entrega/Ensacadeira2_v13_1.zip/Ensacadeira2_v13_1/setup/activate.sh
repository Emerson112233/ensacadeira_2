#!/usr/bin/env bash
# Source this file; it does not print or persist injected credentials.
export ENSACADEIRA2_SETUP_ROOT=/workspace/.cloud-setup/ensacadeira2
export ARDUINO_DIRECTORIES_DATA="$ENSACADEIRA2_SETUP_ROOT/arduino-data"
export ARDUINO_DIRECTORIES_USER="$ENSACADEIRA2_SETUP_ROOT/arduino-user"
export ARDUINO_DIRECTORIES_DOWNLOADS="$ENSACADEIRA2_SETUP_ROOT/downloads"
export ARDUINO_NETWORK_PROXY="${HTTPS_PROXY:-${https_proxy:-}}"
export ENSACADEIRA2_ESP8266_INDEX_URL=https://github.com/esp8266/Arduino/releases/download/3.1.2/package_esp8266com_index.json
export ENSACADEIRA2_FQBN='esp8266:esp8266:d1:xtal=80,vt=flash,exception=disabled,stacksmash=disabled,ssl=all,mmu=3232,non32xfer=fast,eesz=4M2M,ip=lm2f,dbg=Disabled,lvl=None____,wipe=none,baud=921600'
case ":$PATH:" in
  *":$ENSACADEIRA2_SETUP_ROOT/bin:"*) ;;
  *) export PATH="$ENSACADEIRA2_SETUP_ROOT/bin:$PATH" ;;
esac
