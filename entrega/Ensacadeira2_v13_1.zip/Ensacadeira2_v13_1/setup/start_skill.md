# Ensacadeira 2: início de desenvolvimento na nuvem

Use o checkout existente em `/workspace/ensacadeira_2`. Cada tarefa já tem um
ambiente isolado; não crie worktree, salvo pedido explícito do usuário. Preserve
arquivos e alterações existentes. Os anexos originais permanecem no pacote
`Pacote_Manutencao_Ensacadeira2`; o firmware em desenvolvimento é a cópia v13.1.

Ative as ferramentas em cada nova sessão de shell:

```bash
source /workspace/.cloud-setup/ensacadeira2/activate.sh
cd /workspace/ensacadeira_2
arduino-cli version
arduino-cli core list
arduino-cli lib list
```

Requisitos instalados: Arduino CLI 1.3.1, ESP8266 core 3.1.2, Firebase Arduino
Client Library for ESP8266 and ESP32 4.4.17, GFX Library for Arduino 1.6.9,
RTClib 2.1.4 e Adafruit BusIO 1.17.4. Para reproduzir ou atualizar somente a
instalação, execute `bash /workspace/.cloud-setup/ensacadeira2/install.sh`.
O script usa os índices oficiais e valida checksums, sem alterar os fontes.

Valide a lógica e compile o firmware:

```bash
source /workspace/.cloud-setup/ensacadeira2/activate.sh
cd /workspace/ensacadeira_2
python3 tests/v13_1/run_tests.py
arduino-cli compile --fqbn "$ENSACADEIRA2_FQBN" --jobs 2 \
  --build-path "$ENSACADEIRA2_SETUP_ROOT/build-v13-1" \
  firmware/Ensacadeira2_RS485_SP3_Estavel_v13_1
```

O FQBN fixa LOLIN(WeMos) D1 R1, CPU 80 MHz, flash 4 MB e LittleFS 2 MB
(`eesz=4M2M`). Preserve esse particionamento para não deslocar a fila existente.
Os artefatos de compilação ficam fora do checkout. Um comando bem-sucedido de
compilação e testes host valida o desenvolvimento local, mas não comprova
funcionamento físico da máquina.

Não há servidor web ou serviço persistente para iniciar neste workflow. A nuvem
não tem o hardware ESP8266/RS485/display/RTC e não deve gravar a placa, habilitar
OTA, importar JSON no Firebase ou usar credenciais de produção durante os
testes locais. Wi-Fi, leitura física da balança, fluxo de ensaque, armazenamento
LittleFS real, display e autenticação/envio ao Firebase exigem validação separada
na bancada. Nenhuma credencial é necessária para compilar ou executar os testes
host; nunca grave segredos nas instruções ou no controle de versão.

A revisão atual é v13.1: produção com 99999 usa 00500 estimado por saturação; consulte docs/ANALISE_LOGS_V13_1.md. A v13 anterior permanece disponível.
