#!/usr/bin/env bash
set -euo pipefail

# Keep all mutable tool state outside HOME and the project checkout.
ENSACADEIRA2_SETUP_ROOT=/workspace/.cloud-setup/ensacadeira2
mkdir -p "$ENSACADEIRA2_SETUP_ROOT"/{bin,downloads,arduino-data,arduino-user,logs}
cat > "$ENSACADEIRA2_SETUP_ROOT/activate.sh" <<'ACTIVATE'
#!/usr/bin/env bash
# Source this file; it does not print or persist injected credentials.
export ENSACADEIRA2_SETUP_ROOT=/workspace/.cloud-setup/ensacadeira2
export ARDUINO_DIRECTORIES_DATA="$ENSACADEIRA2_SETUP_ROOT/arduino-data"
export ARDUINO_DIRECTORIES_USER="$ENSACADEIRA2_SETUP_ROOT/arduino-user"
export ARDUINO_DIRECTORIES_DOWNLOADS="$ENSACADEIRA2_SETUP_ROOT/downloads"
export ARDUINO_NETWORK_PROXY="${HTTPS_PROXY:-${https_proxy:-}}"
export ENSACADEIRA2_ESP8266_INDEX_URL=https://github.com/esp8266/Arduino/releases/download/3.1.2/package_esp8266com_index.json
export ENSACADEIRA2_FQBN='esp8266:esp8266:d1:xtal=80,vt=flash,exception=disabled,stacksmash=disabled,ssl=all,mmu=3232,non32xfer=fast,eesz=4M2M,ip=lm2f,dbg=Disabled,lvl=None____,wipe=none,baud=921600'
case ":$PATH:" in
  *":$ENSACADEIRA2_SETUP_ROOT/bin:"*) ;;
  *) export PATH="$ENSACADEIRA2_SETUP_ROOT/bin:$PATH" ;;
esac
ACTIVATE
chmod 700 "$ENSACADEIRA2_SETUP_ROOT/activate.sh"
source "$ENSACADEIRA2_SETUP_ROOT/activate.sh"

if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  printf '%s\n' 'This installer targets the Linux x86_64 cloud environment.' >&2
  exit 1
fi
for command_name in curl python3 tar sha256sum; do
  command -v "$command_name" >/dev/null
done

cli_version=1.3.1
cli_archive="arduino-cli_${cli_version}_Linux_64bit.tar.gz"
cli_release="https://github.com/arduino/arduino-cli/releases/download/v${cli_version}"
cli_checksums="${cli_version}-checksums.txt"
cli_binary="$ENSACADEIRA2_SETUP_ROOT/bin/arduino-cli"

# The existing binary was verified during onboarding. Install/replace only
# when the pinned CLI is missing; verify the official archive before extraction.
if [[ ! -x "$cli_binary" ]] || ! "$cli_binary" version --format json | python3 -c 'import json,sys; sys.exit(json.load(sys.stdin).get("VersionString") != "1.3.1")'; then
  curl --fail --location --show-error --retry 3 \
    "$cli_release/$cli_checksums" \
    --output "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_checksums.part"
  mv "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_checksums.part" "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_checksums"
  curl --fail --location --show-error --retry 3 \
    "$cli_release/$cli_archive" \
    --output "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_archive.part"
  mv "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_archive.part" "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_archive"
  awk -v filename="$cli_archive" \
    '$2 == filename || $2 == "*" filename {print; found=1} END {if (!found) exit 1}' \
    "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_checksums" \
    > "$ARDUINO_DIRECTORIES_DOWNLOADS/arduino-cli.sha256"
  (cd "$ARDUINO_DIRECTORIES_DOWNLOADS" && sha256sum --check arduino-cli.sha256)
  tar -xzf "$ARDUINO_DIRECTORIES_DOWNLOADS/$cli_archive" \
    -C "$ENSACADEIRA2_SETUP_ROOT/bin" arduino-cli
fi

# Arduino CLI verifies the package/library checksums supplied by its indexes.
arduino-cli core update-index --additional-urls "$ENSACADEIRA2_ESP8266_INDEX_URL"
arduino-cli core install esp8266:esp8266@3.1.2 \
  --additional-urls "$ENSACADEIRA2_ESP8266_INDEX_URL"
arduino-cli lib update-index
arduino-cli lib install --no-deps \
  'Firebase Arduino Client Library for ESP8266 and ESP32@4.4.17' \
  'GFX Library for Arduino@1.6.9' \
  'RTClib@2.1.4' \
  'Adafruit BusIO@1.17.4'

arduino-cli version
arduino-cli core list
arduino-cli lib list
